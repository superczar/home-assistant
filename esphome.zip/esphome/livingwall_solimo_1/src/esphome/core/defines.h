#pragma once
#define USE_API
#define USE_CAPTIVE_PORTAL
#define USE_ESP8266_PREFERENCES_FLASH
#define USE_JSON
#define USE_LIGHT
#define USE_LOGGER
#define USE_WIFI
