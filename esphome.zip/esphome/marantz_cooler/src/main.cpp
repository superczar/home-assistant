// Auto generated code by esphome
// ========== AUTO GENERATED INCLUDE BLOCK BEGIN ===========
#include "esphome.h"
using namespace esphome;
using namespace binary_sensor;
using namespace switch_;
logger::Logger *logger_logger;
status_led::StatusLED *status_led_statusled;
web_server_base::WebServerBase *web_server_base_webserverbase;
captive_portal::CaptivePortal *captive_portal_captiveportal;
wifi::WiFiComponent *wifi_wificomponent;
ota::OTAComponent *ota_otacomponent;
api::APIServer *api_apiserver;
using namespace api;
gpio::GPIOBinarySensor *gpio_gpiobinarysensor;
gpio::GPIOSwitch *relay;
binary_sensor::PressTrigger *binary_sensor_presstrigger;
Automation<> *automation;
switch_::ToggleAction<> *switch__toggleaction;
// ========== AUTO GENERATED INCLUDE BLOCK END ==========="

void setup() {
  // ===== DO NOT EDIT ANYTHING BELOW THIS LINE =====
  // ========== AUTO GENERATED CODE BEGIN ===========
  // async_tcp:
  // esphome:
  //   name: marantz_cooler
  //   platform: ESP8266
  //   board: esp01_1m
  //   esp8266_restore_from_flash: false
  //   arduino_version: espressif8266@2.2.3
  //   includes: []
  //   board_flash_mode: dout
  //   libraries: []
  //   platformio_options: {}
  //   build_path: marantz_cooler
  App.pre_setup("marantz_cooler", __DATE__ ", " __TIME__);
  // binary_sensor:
  // switch:
  // logger:
  //   id: logger_logger
  //   logs: {}
  //   level: DEBUG
  //   hardware_uart: UART0
  //   esp8266_store_log_strings_in_flash: true
  //   tx_buffer_size: 512
  //   baud_rate: 115200
  logger_logger = new logger::Logger(115200, 512, logger::UART_SELECTION_UART0);
  logger_logger->pre_setup();
  App.register_component(logger_logger);
  // status_led:
  //   pin:
  //     number: 13
  //     inverted: true
  //     mode: OUTPUT
  //   id: status_led_statusled
  status_led_statusled = new status_led::StatusLED(new GPIOPin(13, OUTPUT, true));
  App.register_component(status_led_statusled);
  status_led_statusled->pre_setup();
  // web_server_base:
  //   id: web_server_base_webserverbase
  web_server_base_webserverbase = new web_server_base::WebServerBase();
  App.register_component(web_server_base_webserverbase);
  // captive_portal:
  //   id: captive_portal_captiveportal
  //   web_server_base_id: web_server_base_webserverbase
  captive_portal_captiveportal = new captive_portal::CaptivePortal(web_server_base_webserverbase);
  App.register_component(captive_portal_captiveportal);
  // wifi:
  //   ap:
  //     ssid: Marantz Cooler Fallback Hotspot
  //     password: dJBnoTY1QUqx
  //     id: wifi_wifiap
  //     ap_timeout: 1min
  //   id: wifi_wificomponent
  //   power_save_mode: NONE
  //   domain: .local
  //   fast_connect: false
  //   output_power: 20.0
  //   reboot_timeout: 15min
  //   networks:
  //   - ssid: ORBI55
  //     password: fluffytuba408
  //     id: wifi_wifiap_2
  //     priority: 0.0
  //   use_address: marantz_cooler.local
  wifi_wificomponent = new wifi::WiFiComponent();
  wifi_wificomponent->set_use_address("marantz_cooler.local");
  wifi::WiFiAP wifi_wifiap_2 = wifi::WiFiAP();
  wifi_wifiap_2.set_ssid("ORBI55");
  wifi_wifiap_2.set_password("fluffytuba408");
  wifi_wifiap_2.set_priority(0.0f);
  wifi_wificomponent->add_sta(wifi_wifiap_2);
  wifi::WiFiAP wifi_wifiap = wifi::WiFiAP();
  wifi_wifiap.set_ssid("Marantz Cooler Fallback Hotspot");
  wifi_wifiap.set_password("dJBnoTY1QUqx");
  wifi_wificomponent->set_ap(wifi_wifiap);
  wifi_wificomponent->set_ap_timeout(60000);
  wifi_wificomponent->set_reboot_timeout(900000);
  wifi_wificomponent->set_power_save_mode(wifi::WIFI_POWER_SAVE_NONE);
  wifi_wificomponent->set_fast_connect(false);
  wifi_wificomponent->set_output_power(20.0f);
  App.register_component(wifi_wificomponent);
  // ota:
  //   id: ota_otacomponent
  //   safe_mode: true
  //   password: ''
  //   port: 8266
  ota_otacomponent = new ota::OTAComponent();
  ota_otacomponent->set_port(8266);
  ota_otacomponent->set_auth_password("");
  App.register_component(ota_otacomponent);
  ota_otacomponent->start_safe_mode();
  // api:
  //   id: api_apiserver
  //   password: ''
  //   port: 6053
  //   reboot_timeout: 15min
  api_apiserver = new api::APIServer();
  App.register_component(api_apiserver);
  api_apiserver->set_port(6053);
  api_apiserver->set_password("");
  api_apiserver->set_reboot_timeout(900000);
  // binary_sensor.gpio:
  //   platform: gpio
  //   pin:
  //     number: 1
  //     mode: INPUT_PULLUP
  //     inverted: true
  //   name: cooler button
  //   on_press:
  //   - then:
  //     - switch.toggle:
  //         id: relay
  //       type_id: switch__toggleaction
  //     trigger_id: binary_sensor_presstrigger
  //     automation_id: automation
  //   id: gpio_gpiobinarysensor
  gpio_gpiobinarysensor = new gpio::GPIOBinarySensor();
  App.register_component(gpio_gpiobinarysensor);
  // switch.gpio:
  //   platform: gpio
  //   name: Marantz 6010 Cooler
  //   pin:
  //     number: 14
  //     inverted: false
  //     mode: OUTPUT
  //   id: relay
  //   interlock_wait_time: 0ms
  //   restore_mode: RESTORE_DEFAULT_OFF
  relay = new gpio::GPIOSwitch();
  App.register_component(relay);
  App.register_binary_sensor(gpio_gpiobinarysensor);
  gpio_gpiobinarysensor->set_name("cooler button");
  binary_sensor_presstrigger = new binary_sensor::PressTrigger(gpio_gpiobinarysensor);
  automation = new Automation<>(binary_sensor_presstrigger);
  App.register_switch(relay);
  relay->set_name("Marantz 6010 Cooler");
  switch__toggleaction = new switch_::ToggleAction<>(relay);
  relay->set_pin(new GPIOPin(14, OUTPUT, false));
  relay->set_restore_mode(gpio::GPIO_SWITCH_RESTORE_DEFAULT_OFF);
  automation->add_actions({switch__toggleaction});
  gpio_gpiobinarysensor->set_pin(new GPIOPin(1, INPUT_PULLUP, true));
  // =========== AUTO GENERATED CODE END ============
  // ========= YOU CAN EDIT AFTER THIS LINE =========
  App.setup();
}

void loop() {
  App.loop();
}
