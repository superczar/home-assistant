// Auto generated code by esphome
// ========== AUTO GENERATED INCLUDE BLOCK BEGIN ===========
#include "esphome.h"
using namespace esphome;
using namespace switch_;
logger::Logger *logger_logger;
web_server_base::WebServerBase *web_server_base_webserverbase;
captive_portal::CaptivePortal *captive_portal_captiveportal;
wifi::WiFiComponent *wifi_wificomponent;
ota::OTAComponent *ota_otacomponent;
api::APIServer *api_apiserver;
using namespace sensor;
using namespace api;
gpio::GPIOSwitch *gpio_gpioswitch;
gpio::GPIOSwitch *gpio_gpioswitch_2;
dallas::ESPOneWire *dallas_esponewire;
dallas::DallasComponent *dallas_dallascomponent;
dallas::DallasTemperatureSensor *dallas_dallastemperaturesensor;
// ========== AUTO GENERATED INCLUDE BLOCK END ==========="

void setup() {
  // ===== DO NOT EDIT ANYTHING BELOW THIS LINE =====
  // ========== AUTO GENERATED CODE BEGIN ===========
  // async_tcp:
  // esphome:
  //   name: av_rack
  //   platform: ESP8266
  //   board: esp01_1m
  //   board_flash_mode: dout
  //   arduino_version: espressif8266@2.2.3
  //   includes: []
  //   build_path: av_rack
  //   platformio_options: {}
  //   libraries: []
  //   esp8266_restore_from_flash: false
  App.pre_setup("av_rack", __DATE__ ", " __TIME__);
  // switch:
  // logger:
  //   id: logger_logger
  //   level: DEBUG
  //   tx_buffer_size: 512
  //   esp8266_store_log_strings_in_flash: true
  //   hardware_uart: UART0
  //   baud_rate: 115200
  //   logs: {}
  logger_logger = new logger::Logger(115200, 512, logger::UART_SELECTION_UART0);
  logger_logger->pre_setup();
  App.register_component(logger_logger);
  // web_server_base:
  //   id: web_server_base_webserverbase
  web_server_base_webserverbase = new web_server_base::WebServerBase();
  App.register_component(web_server_base_webserverbase);
  // captive_portal:
  //   id: captive_portal_captiveportal
  //   web_server_base_id: web_server_base_webserverbase
  captive_portal_captiveportal = new captive_portal::CaptivePortal(web_server_base_webserverbase);
  App.register_component(captive_portal_captiveportal);
  // wifi:
  //   ap:
  //     ssid: Av Rack Fallback Hotspot
  //     password: B4PwmcVRocpa
  //     id: wifi_wifiap
  //     ap_timeout: 1min
  //   id: wifi_wificomponent
  //   reboot_timeout: 15min
  //   fast_connect: false
  //   power_save_mode: NONE
  //   output_power: 20.0
  //   domain: .local
  //   networks:
  //   - ssid: ORBI55
  //     password: fluffytuba408
  //     id: wifi_wifiap_2
  //     priority: 0.0
  //   use_address: av_rack.local
  wifi_wificomponent = new wifi::WiFiComponent();
  wifi_wificomponent->set_use_address("av_rack.local");
  wifi::WiFiAP wifi_wifiap_2 = wifi::WiFiAP();
  wifi_wifiap_2.set_ssid("ORBI55");
  wifi_wifiap_2.set_password("fluffytuba408");
  wifi_wifiap_2.set_priority(0.0f);
  wifi_wificomponent->add_sta(wifi_wifiap_2);
  wifi::WiFiAP wifi_wifiap = wifi::WiFiAP();
  wifi_wifiap.set_ssid("Av Rack Fallback Hotspot");
  wifi_wifiap.set_password("B4PwmcVRocpa");
  wifi_wificomponent->set_ap(wifi_wifiap);
  wifi_wificomponent->set_ap_timeout(60000);
  wifi_wificomponent->set_reboot_timeout(900000);
  wifi_wificomponent->set_power_save_mode(wifi::WIFI_POWER_SAVE_NONE);
  wifi_wificomponent->set_fast_connect(false);
  wifi_wificomponent->set_output_power(20.0f);
  App.register_component(wifi_wificomponent);
  // ota:
  //   password: ''
  //   id: ota_otacomponent
  //   safe_mode: true
  //   port: 8266
  ota_otacomponent = new ota::OTAComponent();
  ota_otacomponent->set_port(8266);
  ota_otacomponent->set_auth_password("");
  App.register_component(ota_otacomponent);
  ota_otacomponent->start_safe_mode();
  // api:
  //   password: ''
  //   id: api_apiserver
  //   port: 6053
  //   reboot_timeout: 15min
  api_apiserver = new api::APIServer();
  App.register_component(api_apiserver);
  // sensor:
  api_apiserver->set_port(6053);
  api_apiserver->set_password("");
  api_apiserver->set_reboot_timeout(900000);
  // dallas:
  //   pin:
  //     number: 2
  //     inverted: false
  //     mode: INPUT
  //   one_wire_id: dallas_esponewire
  //   id: dallas_dallascomponent
  //   update_interval: 60s
  // switch.gpio:
  //   platform: gpio
  //   name: Denon Fan
  //   pin:
  //     number: 12
  //     inverted: false
  //     mode: OUTPUT
  //   id: gpio_gpioswitch
  //   interlock_wait_time: 0ms
  //   restore_mode: RESTORE_DEFAULT_OFF
  gpio_gpioswitch = new gpio::GPIOSwitch();
  App.register_component(gpio_gpioswitch);
  // switch.gpio:
  //   platform: gpio
  //   name: AV Rack Fan
  //   pin:
  //     number: 13
  //     inverted: false
  //     mode: OUTPUT
  //   id: gpio_gpioswitch_2
  //   interlock_wait_time: 0ms
  //   restore_mode: RESTORE_DEFAULT_OFF
  gpio_gpioswitch_2 = new gpio::GPIOSwitch();
  App.register_component(gpio_gpioswitch_2);
  // sensor.dallas:
  //   platform: dallas
  //   address: 0xFE000005B68D2428
  //   name: AV Rack Temperature
  //   icon: mdi:thermometer
  //   id: dallas_dallastemperaturesensor
  //   force_update: false
  //   unit_of_measurement: °C
  //   dallas_id: dallas_dallascomponent
  //   resolution: 12
  //   accuracy_decimals: 1
  dallas_esponewire = new dallas::ESPOneWire(new GPIOPin(2, INPUT, false));
  dallas_dallascomponent = new dallas::DallasComponent(dallas_esponewire);
  dallas_dallascomponent->set_update_interval(60000);
  App.register_component(dallas_dallascomponent);
  App.register_switch(gpio_gpioswitch);
  gpio_gpioswitch->set_name("Denon Fan");
  App.register_switch(gpio_gpioswitch_2);
  gpio_gpioswitch_2->set_name("AV Rack Fan");
  dallas_dallastemperaturesensor = dallas_dallascomponent->get_sensor_by_address(0xFE000005B68D2428, 12);
  App.register_sensor(dallas_dallastemperaturesensor);
  dallas_dallastemperaturesensor->set_name("AV Rack Temperature");
  dallas_dallastemperaturesensor->set_unit_of_measurement("\302\260C");
  dallas_dallastemperaturesensor->set_icon("mdi:thermometer");
  dallas_dallastemperaturesensor->set_accuracy_decimals(1);
  dallas_dallastemperaturesensor->set_force_update(false);
  gpio_gpioswitch->set_pin(new GPIOPin(12, OUTPUT, false));
  gpio_gpioswitch->set_restore_mode(gpio::GPIO_SWITCH_RESTORE_DEFAULT_OFF);
  gpio_gpioswitch_2->set_pin(new GPIOPin(13, OUTPUT, false));
  gpio_gpioswitch_2->set_restore_mode(gpio::GPIO_SWITCH_RESTORE_DEFAULT_OFF);
  // =========== AUTO GENERATED CODE END ============
  // ========= YOU CAN EDIT AFTER THIS LINE =========
  App.setup();
}

void loop() {
  App.loop();
}
