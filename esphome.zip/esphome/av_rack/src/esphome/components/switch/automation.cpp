#include "automation.h"
#include "esphome/core/log.h"

namespace esphome {
namespace switch_ {

static const char *TAG = "switch.automation";

}  // namespace switch_
}  // namespace esphome
