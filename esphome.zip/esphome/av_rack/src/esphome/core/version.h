#pragma once
#define ESPHOME_VERSION "1.14.5"
