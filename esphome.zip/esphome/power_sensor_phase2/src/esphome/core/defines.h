#pragma once
#define USE_API
#define USE_CAPTIVE_PORTAL
#define USE_JSON
#define USE_LOGGER
#define USE_WIFI
