// Auto generated code by esphome
// ========== AUTO GENERATED INCLUDE BLOCK BEGIN ===========
#include "esphome.h"
using namespace esphome;
using namespace light;
logger::Logger *logger_logger;
web_server_base::WebServerBase *web_server_base_webserverbase;
captive_portal::CaptivePortal *captive_portal_captiveportal;
wifi::WiFiComponent *wifi_wificomponent;
ota::OTAComponent *ota_otacomponent;
api::APIServer *api_apiserver;
using namespace api;
web_server::WebServer *web_server_webserver;
using namespace json;
using namespace output;
esp8266_pwm::ESP8266PWM *red;
esp8266_pwm::ESP8266PWM *green;
esp8266_pwm::ESP8266PWM *blue;
esp8266_pwm::ESP8266PWM *cold_white;
esp8266_pwm::ESP8266PWM *warm_white;
cwww::CWWWLightOutput *cwww_cwwwlightoutput;
light::LightState *light_lightstate;
// ========== AUTO GENERATED INCLUDE BLOCK END ==========="

void setup() {
  // ===== DO NOT EDIT ANYTHING BELOW THIS LINE =====
  // ========== AUTO GENERATED CODE BEGIN ===========
  // async_tcp:
  // esphome:
  //   name: livingwall_solimo_2
  //   platform: ESP8266
  //   board: esp01_1m
  //   esp8266_restore_from_flash: true
  //   board_flash_mode: dout
  //   includes: []
  //   arduino_version: espressif8266@2.2.3
  //   platformio_options: {}
  //   libraries: []
  //   build_path: livingwall_solimo_2
  App.pre_setup("livingwall_solimo_2", __DATE__ ", " __TIME__);
  // light:
  // logger:
  //   hardware_uart: UART0
  //   esp8266_store_log_strings_in_flash: true
  //   level: DEBUG
  //   logs: {}
  //   tx_buffer_size: 512
  //   id: logger_logger
  //   baud_rate: 115200
  logger_logger = new logger::Logger(115200, 512, logger::UART_SELECTION_UART0);
  logger_logger->pre_setup();
  App.register_component(logger_logger);
  // web_server_base:
  //   id: web_server_base_webserverbase
  web_server_base_webserverbase = new web_server_base::WebServerBase();
  App.register_component(web_server_base_webserverbase);
  // captive_portal:
  //   web_server_base_id: web_server_base_webserverbase
  //   id: captive_portal_captiveportal
  captive_portal_captiveportal = new captive_portal::CaptivePortal(web_server_base_webserverbase);
  App.register_component(captive_portal_captiveportal);
  // wifi:
  //   ap:
  //     ssid: Livingwall Solimo 2
  //     password: uMwLSygSSnar
  //     ap_timeout: 1min
  //     id: wifi_wifiap
  //   output_power: 20.0
  //   fast_connect: false
  //   power_save_mode: NONE
  //   reboot_timeout: 15min
  //   domain: .local
  //   id: wifi_wificomponent
  //   networks:
  //   - ssid: ORBI55
  //     password: fluffytuba408
  //     priority: 0.0
  //     id: wifi_wifiap_2
  //   use_address: livingwall_solimo_2.local
  wifi_wificomponent = new wifi::WiFiComponent();
  wifi_wificomponent->set_use_address("livingwall_solimo_2.local");
  wifi::WiFiAP wifi_wifiap_2 = wifi::WiFiAP();
  wifi_wifiap_2.set_ssid("ORBI55");
  wifi_wifiap_2.set_password("fluffytuba408");
  wifi_wifiap_2.set_priority(0.0f);
  wifi_wificomponent->add_sta(wifi_wifiap_2);
  wifi::WiFiAP wifi_wifiap = wifi::WiFiAP();
  wifi_wifiap.set_ssid("Livingwall Solimo 2");
  wifi_wifiap.set_password("uMwLSygSSnar");
  wifi_wificomponent->set_ap(wifi_wifiap);
  wifi_wificomponent->set_ap_timeout(60000);
  wifi_wificomponent->set_reboot_timeout(900000);
  wifi_wificomponent->set_power_save_mode(wifi::WIFI_POWER_SAVE_NONE);
  wifi_wificomponent->set_fast_connect(false);
  wifi_wificomponent->set_output_power(20.0f);
  App.register_component(wifi_wificomponent);
  // ota:
  //   password: ''
  //   port: 8266
  //   safe_mode: true
  //   id: ota_otacomponent
  ota_otacomponent = new ota::OTAComponent();
  ota_otacomponent->set_port(8266);
  ota_otacomponent->set_auth_password("");
  App.register_component(ota_otacomponent);
  ota_otacomponent->start_safe_mode();
  // api:
  //   reboot_timeout: 15min
  //   password: ''
  //   port: 6053
  //   id: api_apiserver
  api_apiserver = new api::APIServer();
  App.register_component(api_apiserver);
  // web_server:
  //   port: 80
  //   css_url: https:esphome.io/_static/webserver-v1.min.css
  //   web_server_base_id: web_server_base_webserverbase
  //   js_url: https:esphome.io/_static/webserver-v1.min.js
  //   id: web_server_webserver
  api_apiserver->set_port(6053);
  api_apiserver->set_password("");
  api_apiserver->set_reboot_timeout(900000);
  web_server_webserver = new web_server::WebServer(web_server_base_webserverbase);
  App.register_component(web_server_webserver);
  web_server_base_webserverbase->set_port(80);
  web_server_webserver->set_css_url("https://esphome.io/_static/webserver-v1.min.css");
  web_server_webserver->set_js_url("https://esphome.io/_static/webserver-v1.min.js");
  // json:
  // output:
  // output.esp8266_pwm:
  //   platform: esp8266_pwm
  //   id: red
  //   pin:
  //     number: 4
  //     mode: OUTPUT
  //     inverted: false
  //   frequency: 1000.0
  red = new esp8266_pwm::ESP8266PWM();
  App.register_component(red);
  // output.esp8266_pwm:
  //   platform: esp8266_pwm
  //   id: green
  //   pin:
  //     number: 12
  //     mode: OUTPUT
  //     inverted: false
  //   frequency: 1000.0
  green = new esp8266_pwm::ESP8266PWM();
  App.register_component(green);
  // output.esp8266_pwm:
  //   platform: esp8266_pwm
  //   id: blue
  //   pin:
  //     number: 14
  //     mode: OUTPUT
  //     inverted: false
  //   frequency: 1000.0
  blue = new esp8266_pwm::ESP8266PWM();
  App.register_component(blue);
  // output.esp8266_pwm:
  //   platform: esp8266_pwm
  //   id: cold_white
  //   pin:
  //     number: 5
  //     mode: OUTPUT
  //     inverted: false
  //   frequency: 1000.0
  cold_white = new esp8266_pwm::ESP8266PWM();
  App.register_component(cold_white);
  // output.esp8266_pwm:
  //   platform: esp8266_pwm
  //   id: warm_white
  //   pin:
  //     number: 13
  //     mode: OUTPUT
  //     inverted: false
  //   frequency: 1000.0
  warm_white = new esp8266_pwm::ESP8266PWM();
  App.register_component(warm_white);
  // light.cwww:
  //   platform: cwww
  //   name: Living Wall 2
  //   cold_white: cold_white
  //   warm_white: warm_white
  //   cold_white_color_temperature: 152.99877600979192
  //   warm_white_color_temperature: 500.0
  //   gamma_correct: 2.8
  //   output_id: cwww_cwwwlightoutput
  //   restore_mode: RESTORE_DEFAULT_OFF
  //   default_transition_length: 1s
  //   id: light_lightstate
  cwww_cwwwlightoutput = new cwww::CWWWLightOutput();
  light_lightstate = new light::LightState("Living Wall 2", cwww_cwwwlightoutput);
  App.register_light(light_lightstate);
  App.register_component(light_lightstate);
  light_lightstate->set_restore_mode(light::LIGHT_RESTORE_DEFAULT_OFF);
  light_lightstate->set_default_transition_length(1000);
  light_lightstate->set_gamma_correct(2.8f);
  light_lightstate->add_effects({});
  red->set_pin(new GPIOPin(4, OUTPUT, false));
  red->set_frequency(1000.0f);
  green->set_pin(new GPIOPin(12, OUTPUT, false));
  green->set_frequency(1000.0f);
  blue->set_pin(new GPIOPin(14, OUTPUT, false));
  blue->set_frequency(1000.0f);
  cold_white->set_pin(new GPIOPin(5, OUTPUT, false));
  cold_white->set_frequency(1000.0f);
  warm_white->set_pin(new GPIOPin(13, OUTPUT, false));
  warm_white->set_frequency(1000.0f);
  cwww_cwwwlightoutput->set_cold_white(cold_white);
  cwww_cwwwlightoutput->set_cold_white_temperature(152.99877600979192f);
  cwww_cwwwlightoutput->set_warm_white(warm_white);
  cwww_cwwwlightoutput->set_warm_white_temperature(500.0f);
  // =========== AUTO GENERATED CODE END ============
  // ========= YOU CAN EDIT AFTER THIS LINE =========
  App.setup();
}

void loop() {
  App.loop();
}
