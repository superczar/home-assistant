#pragma once
#define USE_API
#define USE_BINARY_SENSOR
#define USE_CAPTIVE_PORTAL
#define USE_LOGGER
#define USE_STATUS_LED
#define USE_SWITCH
#define USE_WIFI
