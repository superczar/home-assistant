// Auto generated code by esphome
// ========== AUTO GENERATED INCLUDE BLOCK BEGIN ===========
#include "esphome.h"
using namespace esphome;
using namespace binary_sensor;
using namespace switch_;
logger::Logger *logger_logger;
status_led::StatusLED *status_led_statusled;
web_server_base::WebServerBase *web_server_base_webserverbase;
captive_portal::CaptivePortal *captive_portal_captiveportal;
wifi::WiFiComponent *wifi_wificomponent;
ota::OTAComponent *ota_otacomponent;
api::APIServer *api_apiserver;
using namespace api;
gpio::GPIOBinarySensor *gpio_gpiobinarysensor;
gpio::GPIOSwitch *relay;
binary_sensor::PressTrigger *binary_sensor_presstrigger;
Automation<> *automation;
switch_::ToggleAction<> *switch__toggleaction;
// ========== AUTO GENERATED INCLUDE BLOCK END ==========="

void setup() {
  // ===== DO NOT EDIT ANYTHING BELOW THIS LINE =====
  // ========== AUTO GENERATED CODE BEGIN ===========
  // async_tcp:
  // esphome:
  //   name: guest_tube
  //   platform: ESP8266
  //   board: esp01_1m
  //   board_flash_mode: dout
  //   includes: []
  //   libraries: []
  //   esp8266_restore_from_flash: false
  //   platformio_options: {}
  //   arduino_version: espressif8266@2.2.3
  //   build_path: guest_tube
  App.pre_setup("guest_tube", __DATE__ ", " __TIME__);
  // binary_sensor:
  // switch:
  // logger:
  //   baud_rate: 115200
  //   id: logger_logger
  //   level: DEBUG
  //   logs: {}
  //   tx_buffer_size: 512
  //   esp8266_store_log_strings_in_flash: true
  //   hardware_uart: UART0
  logger_logger = new logger::Logger(115200, 512, logger::UART_SELECTION_UART0);
  logger_logger->pre_setup();
  App.register_component(logger_logger);
  // status_led:
  //   pin:
  //     number: 13
  //     mode: OUTPUT
  //     inverted: false
  //   id: status_led_statusled
  status_led_statusled = new status_led::StatusLED(new GPIOPin(13, OUTPUT, false));
  App.register_component(status_led_statusled);
  status_led_statusled->pre_setup();
  // web_server_base:
  //   id: web_server_base_webserverbase
  web_server_base_webserverbase = new web_server_base::WebServerBase();
  App.register_component(web_server_base_webserverbase);
  // captive_portal:
  //   web_server_base_id: web_server_base_webserverbase
  //   id: captive_portal_captiveportal
  captive_portal_captiveportal = new captive_portal::CaptivePortal(web_server_base_webserverbase);
  App.register_component(captive_portal_captiveportal);
  // wifi:
  //   ap:
  //     ssid: Guest Tube Fallback Hotspot
  //     password: m9wi7vWyOG0X
  //     id: wifi_wifiap
  //     ap_timeout: 1min
  //   fast_connect: false
  //   output_power: 20.0
  //   id: wifi_wificomponent
  //   reboot_timeout: 15min
  //   domain: .local
  //   power_save_mode: NONE
  //   networks:
  //   - ssid: ORBI55
  //     password: fluffytuba408
  //     priority: 0.0
  //     id: wifi_wifiap_2
  //   use_address: guest_tube.local
  wifi_wificomponent = new wifi::WiFiComponent();
  wifi_wificomponent->set_use_address("guest_tube.local");
  wifi::WiFiAP wifi_wifiap_2 = wifi::WiFiAP();
  wifi_wifiap_2.set_ssid("ORBI55");
  wifi_wifiap_2.set_password("fluffytuba408");
  wifi_wifiap_2.set_priority(0.0f);
  wifi_wificomponent->add_sta(wifi_wifiap_2);
  wifi::WiFiAP wifi_wifiap = wifi::WiFiAP();
  wifi_wifiap.set_ssid("Guest Tube Fallback Hotspot");
  wifi_wifiap.set_password("m9wi7vWyOG0X");
  wifi_wificomponent->set_ap(wifi_wifiap);
  wifi_wificomponent->set_ap_timeout(60000);
  wifi_wificomponent->set_reboot_timeout(900000);
  wifi_wificomponent->set_power_save_mode(wifi::WIFI_POWER_SAVE_NONE);
  wifi_wificomponent->set_fast_connect(false);
  wifi_wificomponent->set_output_power(20.0f);
  App.register_component(wifi_wificomponent);
  // ota:
  //   port: 8266
  //   safe_mode: true
  //   id: ota_otacomponent
  //   password: ''
  ota_otacomponent = new ota::OTAComponent();
  ota_otacomponent->set_port(8266);
  ota_otacomponent->set_auth_password("");
  App.register_component(ota_otacomponent);
  ota_otacomponent->start_safe_mode();
  // api:
  //   port: 6053
  //   id: api_apiserver
  //   password: ''
  //   reboot_timeout: 15min
  api_apiserver = new api::APIServer();
  App.register_component(api_apiserver);
  api_apiserver->set_port(6053);
  api_apiserver->set_password("");
  api_apiserver->set_reboot_timeout(900000);
  // binary_sensor.gpio:
  //   platform: gpio
  //   pin:
  //     number: 1
  //     mode: INPUT_PULLUP
  //     inverted: true
  //   name: Guest Tubelight button
  //   on_press:
  //   - then:
  //     - switch.toggle:
  //         id: relay
  //       type_id: switch__toggleaction
  //     trigger_id: binary_sensor_presstrigger
  //     automation_id: automation
  //   id: gpio_gpiobinarysensor
  gpio_gpiobinarysensor = new gpio::GPIOBinarySensor();
  App.register_component(gpio_gpiobinarysensor);
  // switch.gpio:
  //   platform: gpio
  //   name: Guest Tubelight
  //   pin:
  //     number: 14
  //     mode: OUTPUT
  //     inverted: false
  //   id: relay
  //   interlock_wait_time: 0ms
  //   restore_mode: RESTORE_DEFAULT_OFF
  relay = new gpio::GPIOSwitch();
  App.register_component(relay);
  App.register_binary_sensor(gpio_gpiobinarysensor);
  gpio_gpiobinarysensor->set_name("Guest Tubelight button");
  binary_sensor_presstrigger = new binary_sensor::PressTrigger(gpio_gpiobinarysensor);
  automation = new Automation<>(binary_sensor_presstrigger);
  App.register_switch(relay);
  relay->set_name("Guest Tubelight");
  switch__toggleaction = new switch_::ToggleAction<>(relay);
  relay->set_pin(new GPIOPin(14, OUTPUT, false));
  relay->set_restore_mode(gpio::GPIO_SWITCH_RESTORE_DEFAULT_OFF);
  automation->add_actions({switch__toggleaction});
  gpio_gpiobinarysensor->set_pin(new GPIOPin(1, INPUT_PULLUP, true));
  // =========== AUTO GENERATED CODE END ============
  // ========= YOU CAN EDIT AFTER THIS LINE =========
  App.setup();
}

void loop() {
  App.loop();
}
