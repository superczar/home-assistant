// Auto generated code by esphome
// ========== AUTO GENERATED INCLUDE BLOCK BEGIN ===========
#include "esphome.h"
using namespace esphome;
using namespace switch_;
logger::Logger *logger_logger;
web_server_base::WebServerBase *web_server_base_webserverbase;
captive_portal::CaptivePortal *captive_portal_captiveportal;
wifi::WiFiComponent *wifi_wificomponent;
ota::OTAComponent *ota_otacomponent;
api::APIServer *api_apiserver;
using namespace sensor;
using namespace api;
gpio::GPIOSwitch *gpio_gpioswitch;
dallas::ESPOneWire *dallas_esponewire;
dallas::DallasComponent *dallas_dallascomponent;
dallas::DallasTemperatureSensor *dallas_dallastemperaturesensor;
// ========== AUTO GENERATED INCLUDE BLOCK END ==========="

void setup() {
  // ===== DO NOT EDIT ANYTHING BELOW THIS LINE =====
  // ========== AUTO GENERATED CODE BEGIN ===========
  // async_tcp:
  // esphome:
  //   name: study_light_strip
  //   platform: ESP8266
  //   board: esp01_1m
  //   build_path: study_light_strip
  //   board_flash_mode: dout
  //   includes: []
  //   platformio_options: {}
  //   arduino_version: espressif8266@2.2.3
  //   esp8266_restore_from_flash: false
  //   libraries: []
  App.pre_setup("study_light_strip", __DATE__ ", " __TIME__);
  // switch:
  // logger:
  //   id: logger_logger
  //   level: DEBUG
  //   tx_buffer_size: 512
  //   baud_rate: 115200
  //   logs: {}
  //   hardware_uart: UART0
  //   esp8266_store_log_strings_in_flash: true
  logger_logger = new logger::Logger(115200, 512, logger::UART_SELECTION_UART0);
  logger_logger->pre_setup();
  App.register_component(logger_logger);
  // web_server_base:
  //   id: web_server_base_webserverbase
  web_server_base_webserverbase = new web_server_base::WebServerBase();
  App.register_component(web_server_base_webserverbase);
  // captive_portal:
  //   web_server_base_id: web_server_base_webserverbase
  //   id: captive_portal_captiveportal
  captive_portal_captiveportal = new captive_portal::CaptivePortal(web_server_base_webserverbase);
  App.register_component(captive_portal_captiveportal);
  // wifi:
  //   ap:
  //     ssid: Study Light Strip
  //     password: bea1tihz90DH
  //     id: wifi_wifiap
  //     ap_timeout: 1min
  //   power_save_mode: NONE
  //   fast_connect: false
  //   id: wifi_wificomponent
  //   domain: .local
  //   output_power: 20.0
  //   reboot_timeout: 15min
  //   networks:
  //   - ssid: ORBI55
  //     password: fluffytuba408
  //     id: wifi_wifiap_2
  //     priority: 0.0
  //   use_address: study_light_strip.local
  wifi_wificomponent = new wifi::WiFiComponent();
  wifi_wificomponent->set_use_address("study_light_strip.local");
  wifi::WiFiAP wifi_wifiap_2 = wifi::WiFiAP();
  wifi_wifiap_2.set_ssid("ORBI55");
  wifi_wifiap_2.set_password("fluffytuba408");
  wifi_wifiap_2.set_priority(0.0f);
  wifi_wificomponent->add_sta(wifi_wifiap_2);
  wifi::WiFiAP wifi_wifiap = wifi::WiFiAP();
  wifi_wifiap.set_ssid("Study Light Strip");
  wifi_wifiap.set_password("bea1tihz90DH");
  wifi_wificomponent->set_ap(wifi_wifiap);
  wifi_wificomponent->set_ap_timeout(60000);
  wifi_wificomponent->set_reboot_timeout(900000);
  wifi_wificomponent->set_power_save_mode(wifi::WIFI_POWER_SAVE_NONE);
  wifi_wificomponent->set_fast_connect(false);
  wifi_wificomponent->set_output_power(20.0f);
  App.register_component(wifi_wificomponent);
  // ota:
  //   id: ota_otacomponent
  //   port: 8266
  //   safe_mode: true
  //   password: ''
  ota_otacomponent = new ota::OTAComponent();
  ota_otacomponent->set_port(8266);
  ota_otacomponent->set_auth_password("");
  App.register_component(ota_otacomponent);
  ota_otacomponent->start_safe_mode();
  // api:
  //   id: api_apiserver
  //   reboot_timeout: 15min
  //   port: 6053
  //   password: ''
  api_apiserver = new api::APIServer();
  App.register_component(api_apiserver);
  // sensor:
  api_apiserver->set_port(6053);
  api_apiserver->set_password("");
  api_apiserver->set_reboot_timeout(900000);
  // switch.gpio:
  //   platform: gpio
  //   name: Study LED Strip
  //   pin:
  //     number: 13
  //     mode: OUTPUT
  //     inverted: false
  //   interlock_wait_time: 0ms
  //   id: gpio_gpioswitch
  //   restore_mode: RESTORE_DEFAULT_OFF
  gpio_gpioswitch = new gpio::GPIOSwitch();
  App.register_component(gpio_gpioswitch);
  // dallas:
  //   pin:
  //     number: 2
  //     mode: INPUT
  //     inverted: false
  //   one_wire_id: dallas_esponewire
  //   id: dallas_dallascomponent
  //   update_interval: 60s
  // sensor.dallas:
  //   platform: dallas
  //   address: 0x1001191ECA5C1C28
  //   name: Study Room Temperature
  //   dallas_id: dallas_dallascomponent
  //   resolution: 12
  //   accuracy_decimals: 1
  //   unit_of_measurement: °C
  //   id: dallas_dallastemperaturesensor
  //   icon: mdi:thermometer
  //   force_update: false
  App.register_switch(gpio_gpioswitch);
  gpio_gpioswitch->set_name("Study LED Strip");
  dallas_esponewire = new dallas::ESPOneWire(new GPIOPin(2, INPUT, false));
  dallas_dallascomponent = new dallas::DallasComponent(dallas_esponewire);
  dallas_dallascomponent->set_update_interval(60000);
  App.register_component(dallas_dallascomponent);
  dallas_dallastemperaturesensor = dallas_dallascomponent->get_sensor_by_address(0x1001191ECA5C1C28, 12);
  App.register_sensor(dallas_dallastemperaturesensor);
  dallas_dallastemperaturesensor->set_name("Study Room Temperature");
  dallas_dallastemperaturesensor->set_unit_of_measurement("\302\260C");
  dallas_dallastemperaturesensor->set_icon("mdi:thermometer");
  dallas_dallastemperaturesensor->set_accuracy_decimals(1);
  dallas_dallastemperaturesensor->set_force_update(false);
  gpio_gpioswitch->set_pin(new GPIOPin(13, OUTPUT, false));
  gpio_gpioswitch->set_restore_mode(gpio::GPIO_SWITCH_RESTORE_DEFAULT_OFF);
  // =========== AUTO GENERATED CODE END ============
  // ========= YOU CAN EDIT AFTER THIS LINE =========
  App.setup();
}

void loop() {
  App.loop();
}
