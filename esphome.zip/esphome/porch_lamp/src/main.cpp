// Auto generated code by esphome
// ========== AUTO GENERATED INCLUDE BLOCK BEGIN ===========
#include "esphome.h"
using namespace esphome;
using namespace switch_;
logger::Logger *logger_logger;
web_server_base::WebServerBase *web_server_base_webserverbase;
captive_portal::CaptivePortal *captive_portal_captiveportal;
wifi::WiFiComponent *wifi_wificomponent;
ota::OTAComponent *ota_otacomponent;
api::APIServer *api_apiserver;
using namespace api;
gpio::GPIOSwitch *relay;
// ========== AUTO GENERATED INCLUDE BLOCK END ==========="

void setup() {
  // ===== DO NOT EDIT ANYTHING BELOW THIS LINE =====
  // ========== AUTO GENERATED CODE BEGIN ===========
  // async_tcp:
  // esphome:
  //   name: porch_lamp
  //   platform: ESP8266
  //   board: esp01_1m
  //   libraries: []
  //   platformio_options: {}
  //   board_flash_mode: dout
  //   arduino_version: espressif8266@2.2.3
  //   esp8266_restore_from_flash: false
  //   build_path: porch_lamp
  //   includes: []
  App.pre_setup("porch_lamp", __DATE__ ", " __TIME__);
  // switch:
  // logger:
  //   tx_buffer_size: 512
  //   level: DEBUG
  //   id: logger_logger
  //   esp8266_store_log_strings_in_flash: true
  //   baud_rate: 115200
  //   hardware_uart: UART0
  //   logs: {}
  logger_logger = new logger::Logger(115200, 512, logger::UART_SELECTION_UART0);
  logger_logger->pre_setup();
  App.register_component(logger_logger);
  // web_server_base:
  //   id: web_server_base_webserverbase
  web_server_base_webserverbase = new web_server_base::WebServerBase();
  App.register_component(web_server_base_webserverbase);
  // captive_portal:
  //   web_server_base_id: web_server_base_webserverbase
  //   id: captive_portal_captiveportal
  captive_portal_captiveportal = new captive_portal::CaptivePortal(web_server_base_webserverbase);
  App.register_component(captive_portal_captiveportal);
  // wifi:
  //   ap:
  //     ssid: Porch Lamp Fallback Hotspot
  //     password: BiT4A6wx0Xh9
  //     id: wifi_wifiap
  //     ap_timeout: 1min
  //   domain: .local
  //   id: wifi_wificomponent
  //   output_power: 20.0
  //   reboot_timeout: 15min
  //   power_save_mode: NONE
  //   fast_connect: false
  //   networks:
  //   - ssid: ORBI55
  //     password: fluffytuba408
  //     id: wifi_wifiap_2
  //     priority: 0.0
  //   use_address: porch_lamp.local
  wifi_wificomponent = new wifi::WiFiComponent();
  wifi_wificomponent->set_use_address("porch_lamp.local");
  wifi::WiFiAP wifi_wifiap_2 = wifi::WiFiAP();
  wifi_wifiap_2.set_ssid("ORBI55");
  wifi_wifiap_2.set_password("fluffytuba408");
  wifi_wifiap_2.set_priority(0.0f);
  wifi_wificomponent->add_sta(wifi_wifiap_2);
  wifi::WiFiAP wifi_wifiap = wifi::WiFiAP();
  wifi_wifiap.set_ssid("Porch Lamp Fallback Hotspot");
  wifi_wifiap.set_password("BiT4A6wx0Xh9");
  wifi_wificomponent->set_ap(wifi_wifiap);
  wifi_wificomponent->set_ap_timeout(60000);
  wifi_wificomponent->set_reboot_timeout(900000);
  wifi_wificomponent->set_power_save_mode(wifi::WIFI_POWER_SAVE_NONE);
  wifi_wificomponent->set_fast_connect(false);
  wifi_wificomponent->set_output_power(20.0f);
  App.register_component(wifi_wificomponent);
  // ota:
  //   password: ''
  //   id: ota_otacomponent
  //   port: 8266
  //   safe_mode: true
  ota_otacomponent = new ota::OTAComponent();
  ota_otacomponent->set_port(8266);
  ota_otacomponent->set_auth_password("");
  App.register_component(ota_otacomponent);
  ota_otacomponent->start_safe_mode();
  // api:
  //   password: ''
  //   id: api_apiserver
  //   reboot_timeout: 15min
  //   port: 6053
  api_apiserver = new api::APIServer();
  App.register_component(api_apiserver);
  api_apiserver->set_port(6053);
  api_apiserver->set_password("");
  api_apiserver->set_reboot_timeout(900000);
  // switch.gpio:
  //   platform: gpio
  //   name: Porch Lamp
  //   pin:
  //     number: 12
  //     inverted: false
  //     mode: OUTPUT
  //   id: relay
  //   restore_mode: RESTORE_DEFAULT_OFF
  //   interlock_wait_time: 0ms
  relay = new gpio::GPIOSwitch();
  App.register_component(relay);
  App.register_switch(relay);
  relay->set_name("Porch Lamp");
  relay->set_pin(new GPIOPin(12, OUTPUT, false));
  relay->set_restore_mode(gpio::GPIO_SWITCH_RESTORE_DEFAULT_OFF);
  // =========== AUTO GENERATED CODE END ============
  // ========= YOU CAN EDIT AFTER THIS LINE =========
  App.setup();
}

void loop() {
  App.loop();
}
