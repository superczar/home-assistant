// Auto generated code by esphome
// ========== AUTO GENERATED INCLUDE BLOCK BEGIN ===========
#include "esphome.h"
using namespace esphome;
using namespace switch_;
using namespace binary_sensor;
logger::Logger *logger_logger;
web_server_base::WebServerBase *web_server_base_webserverbase;
captive_portal::CaptivePortal *captive_portal_captiveportal;
wifi::WiFiComponent *wifi_wificomponent;
ota::OTAComponent *ota_otacomponent;
api::APIServer *api_apiserver;
using namespace api;
gpio::GPIOSwitch *gpio_gpioswitch;
gpio::GPIOBinarySensor *gpio_gpiobinarysensor;
// ========== AUTO GENERATED INCLUDE BLOCK END ==========="

void setup() {
  // ===== DO NOT EDIT ANYTHING BELOW THIS LINE =====
  // ========== AUTO GENERATED CODE BEGIN ===========
  // async_tcp:
  // esphome:
  //   name: study_washroom
  //   platform: ESP8266
  //   board: esp01_1m
  //   includes: []
  //   platformio_options: {}
  //   build_path: study_washroom
  //   arduino_version: espressif8266@2.2.3
  //   libraries: []
  //   esp8266_restore_from_flash: false
  //   board_flash_mode: dout
  App.pre_setup("study_washroom", __DATE__ ", " __TIME__);
  // switch:
  // binary_sensor:
  // logger:
  //   logs: {}
  //   esp8266_store_log_strings_in_flash: true
  //   id: logger_logger
  //   baud_rate: 115200
  //   hardware_uart: UART0
  //   level: DEBUG
  //   tx_buffer_size: 512
  logger_logger = new logger::Logger(115200, 512, logger::UART_SELECTION_UART0);
  logger_logger->pre_setup();
  App.register_component(logger_logger);
  // web_server_base:
  //   id: web_server_base_webserverbase
  web_server_base_webserverbase = new web_server_base::WebServerBase();
  App.register_component(web_server_base_webserverbase);
  // captive_portal:
  //   web_server_base_id: web_server_base_webserverbase
  //   id: captive_portal_captiveportal
  captive_portal_captiveportal = new captive_portal::CaptivePortal(web_server_base_webserverbase);
  App.register_component(captive_portal_captiveportal);
  // wifi:
  //   ap:
  //     ssid: Study Washroom Fallback Hotspot
  //     password: Itjvske8mZ7W
  //     ap_timeout: 1min
  //     id: wifi_wifiap
  //   domain: .local
  //   reboot_timeout: 15min
  //   fast_connect: false
  //   output_power: 20.0
  //   id: wifi_wificomponent
  //   power_save_mode: NONE
  //   networks:
  //   - ssid: ORBI55
  //     password: fluffytuba408
  //     id: wifi_wifiap_2
  //     priority: 0.0
  //   use_address: study_washroom.local
  wifi_wificomponent = new wifi::WiFiComponent();
  wifi_wificomponent->set_use_address("study_washroom.local");
  wifi::WiFiAP wifi_wifiap_2 = wifi::WiFiAP();
  wifi_wifiap_2.set_ssid("ORBI55");
  wifi_wifiap_2.set_password("fluffytuba408");
  wifi_wifiap_2.set_priority(0.0f);
  wifi_wificomponent->add_sta(wifi_wifiap_2);
  wifi::WiFiAP wifi_wifiap = wifi::WiFiAP();
  wifi_wifiap.set_ssid("Study Washroom Fallback Hotspot");
  wifi_wifiap.set_password("Itjvske8mZ7W");
  wifi_wificomponent->set_ap(wifi_wifiap);
  wifi_wificomponent->set_ap_timeout(60000);
  wifi_wificomponent->set_reboot_timeout(900000);
  wifi_wificomponent->set_power_save_mode(wifi::WIFI_POWER_SAVE_NONE);
  wifi_wificomponent->set_fast_connect(false);
  wifi_wificomponent->set_output_power(20.0f);
  App.register_component(wifi_wificomponent);
  // ota:
  //   port: 8266
  //   id: ota_otacomponent
  //   safe_mode: true
  //   password: ''
  ota_otacomponent = new ota::OTAComponent();
  ota_otacomponent->set_port(8266);
  ota_otacomponent->set_auth_password("");
  App.register_component(ota_otacomponent);
  ota_otacomponent->start_safe_mode();
  // api:
  //   port: 6053
  //   id: api_apiserver
  //   reboot_timeout: 15min
  //   password: ''
  api_apiserver = new api::APIServer();
  App.register_component(api_apiserver);
  api_apiserver->set_port(6053);
  api_apiserver->set_password("");
  api_apiserver->set_reboot_timeout(900000);
  // switch.gpio:
  //   platform: gpio
  //   name: Study washroom exhaust
  //   pin:
  //     number: 12
  //     inverted: false
  //     mode: OUTPUT
  //   id: gpio_gpioswitch
  //   interlock_wait_time: 0ms
  //   restore_mode: RESTORE_DEFAULT_OFF
  gpio_gpioswitch = new gpio::GPIOSwitch();
  App.register_component(gpio_gpioswitch);
  // binary_sensor.gpio:
  //   platform: gpio
  //   pin:
  //     number: 14
  //     inverted: false
  //     mode: INPUT
  //   name: Study Motion Sensor
  //   device_class: motion
  //   id: gpio_gpiobinarysensor
  gpio_gpiobinarysensor = new gpio::GPIOBinarySensor();
  App.register_component(gpio_gpiobinarysensor);
  App.register_switch(gpio_gpioswitch);
  gpio_gpioswitch->set_name("Study washroom exhaust");
  App.register_binary_sensor(gpio_gpiobinarysensor);
  gpio_gpiobinarysensor->set_name("Study Motion Sensor");
  gpio_gpiobinarysensor->set_device_class("motion");
  gpio_gpioswitch->set_pin(new GPIOPin(12, OUTPUT, false));
  gpio_gpioswitch->set_restore_mode(gpio::GPIO_SWITCH_RESTORE_DEFAULT_OFF);
  gpio_gpiobinarysensor->set_pin(new GPIOPin(14, INPUT, false));
  // =========== AUTO GENERATED CODE END ============
  // ========= YOU CAN EDIT AFTER THIS LINE =========
  App.setup();
}

void loop() {
  App.loop();
}
