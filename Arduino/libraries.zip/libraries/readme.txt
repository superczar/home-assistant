20:01:44.400 -> MQTT >> [hasend/power1] 887
20:01:44.400 -> 887
20:01:44.400 -> MQTT >> [hasend/tempodr] 24.3
20:01:44.400 -> hasend/tempodr: 24.3
20:01:45.018 -> MQTT >> [hasend/power2] 12
20:01:45.018 -> hasend/power2: 12
20:01:53.152 -> MQTT >> [hasend/power1] 884
20:01:53.152 -> 884
20:01:53.218 -> MQTT >> [hasend/tempodr] 24.3
20:01:53.218 -> hasend/tempodr: 24.3
20:01:54.858 -> MQTT >> [hasend/power2] 12
20:01:54.858 -> hasend/power2: 12
20:02:03.166 -> MQTT >> [hasend/power1] 896
20:02:03.166 -> 896
20:02:03.341 -> MQTT >> [hasend/tempodr] 24.3
20:02:03.341 -> hasend/tempodr: 24.3
20:02:03.375 -> MQTT >> [hasend/energydly] 20.47999999999998
20:02:03.375 -> hasend/energydly: 20.47999999999998
20:02:03.442 -> MQTT >> [hasend/energymnthly] 60.219999999999980
20:02:03.442 -> hasend/energymnthly: 60.219999999999980
20:02:04.830 -> MQTT >> [hasend/power2] 12
20:02:04.830 -> hasend/power2: 12
20:02:13.189 -> MQTT >> [hasend/power1] 883
20:02:13.189 -> 883
20:02:13.337 -> MQTT >> [hasend/tempodr] 24.3
20:02:13.337 -> hasend/tempodr: 24.3
20:02:14.831 -> MQTT >> [hasend/power2] 12
20:02:14.831 -> hasend/power2: 12
20:02:23.250 -> MQTT >> [hasend/power1] 885
20:02:23.250 -> 885
20:02:23.322 -> MQTT >> [hasend/tempodr] 24.3
20:02:23.322 -> hasend/tempodr: 24.3
20:02:24.885 -> MQTT >> [hasend/power2] 12
20:02:24.885 -> hasend/power2: 12
20:02:33.150 -> MQTT >> [hasend/power1] 885
20:02:33.184 -> 885
20:02:33.393 -> MQTT >> [hasend/tempodr] 24.3
20:02:33.393 -> hasend/tempodr: 24.3
20:02:34.892 -> MQTT >> [hasend/power2] 12
20:02:34.892 -> hasend/power2: 12
20:02:43.210 -> MQTT >> [hasend/power1] 884
20:02:43.210 -> 884
20:02:43.318 -> MQTT >> [hasend/tempodr] 24.3
20:02:43.318 -> hasend/tempodr: 24.3
20:02:43.385 -> MQTT >> [hasend/energydly] 20.48999999999998
20:02:43.385 -> hasend/energydly: 20.48999999999998
20:02:43.451 -> MQTT >> [hasend/energymnthly] 60.229999999999980
20:02:43.451 -> hasend/energymnthly: 60.229999999999980
20:02:44.874 -> MQTT >> [hasend/power2] 12
20:02:44.874 -> hasend/power2: 12
20:02:53.211 -> MQTT >> [hasend/power1] 880
20:02:53.211 -> 880
20:02:53.319 -> MQTT >> [hasend/tempodr] 24.3
20:02:53.319 -> hasend/tempodr: 24.3
20:02:54.879 -> MQTT >> [hasend/power2] 12
20:02:54.879 -> hasend/power2: 12
20:03:03.184 -> MQTT >> [hasend/power1] 887
20:03:03.184 -> 887
20:03:03.392 -> MQTT >> [hasend/tempodr] 24.3
20:03:03.392 -> hasend/tempodr: 24.3
20:03:04.833 -> MQTT >> [hasend/power2] 12
20:03:04.833 -> hasend/power2: 12
20:03:13.203 -> MQTT >> [hasend/power1] 883
20:03:13.203 -> 883
20:03:13.305 -> MQTT >> [hasend/tempodr] 24.2
20:03:13.305 -> hasend/tempodr: 24.2
20:03:14.881 -> MQTT >> [hasend/power2] 12
20:03:14.881 -> hasend/power2: 12
20:03:23.174 -> MQTT >> [hasend/power1] 832
20:03:23.174 -> 832
20:03:23.250 -> MQTT >> [hasend/tempodr] 24.1
20:03:23.288 -> hasend/tempodr: 24.1
20:03:23.326 -> MQTT >> [hasend/energydly] 20.49999999999998
20:03:23.326 -> hasend/energydly: 20.49999999999998
20:03:23.362 -> MQTT >> [hasend/energymnthly] 60.239999999999980
20:03:23.396 -> hasend/energymnthly: 60.239999999999980
20:03:24.867 -> MQTT >> [hasend/power2] 12
20:03:24.867 -> hasend/power2: 12
20:03:33.364 -> MQTT >> [hasend/power1] 835
20:03:33.364 -> 835
20:03:33.622 -> MQTT >> [hasend/tempodr] 24.2
20:03:33.622 -> hasend/tempodr: 24.2
20:03:34.891 -> MQTT >> [hasend/power2] 12
20:03:34.891 -> hasend/power2: 12
20:03:43.198 -> MQTT >> [hasend/power1] 834
20:03:43.198 -> 834
20:03:43.467 -> MQTT >> [hasend/tempodr] 24.2
20:03:43.467 -> hasend/tempodr: 24.2
20:03:44.848 -> MQTT >> [hasend/power2] 12
20:03:44.848 -> hasend/power2: 12
20:03:53.249 -> MQTT >> [hasend/power1] 836
20:03:53.249 -> 836
20:03:53.323 -> MQTT >> [hasend/tempodr] 24.2
20:03:53.323 -> hasend/tempodr: 24.2
20:03:54.890 -> MQTT >> [hasend/power2] 12
20:03:54.890 -> hasend/power2: 12
20:04:03.207 -> MQTT >> [hasend/power1] 848
20:04:03.207 -> 848
20:04:03.278 -> MQTT >> [hasend/tempodr] 24.3
20:04:03.278 -> hasend/tempodr: 24.3
20:04:04.915 -> MQTT >> [hasend/power2] 12
20:04:04.915 -> hasend/power2: 12
20:04:13.227 -> MQTT >> [hasend/power1] 845
20:04:13.262 -> 845
20:04:13.433 -> MQTT >> [hasend/tempodr] 24.3
20:04:13.433 -> hasend/tempodr: 24.3
20:04:13.467 -> MQTT >> [hasend/energydly] 20.50999999999998
20:04:13.467 -> hasend/energydly: 20.50999999999998
20:04:13.535 -> MQTT >> [hasend/energymnthly] 60.249999999999980
20:04:13.535 -> hasend/energymnthly: 60.249999999999980
20:04:14.860 -> MQTT >> [hasend/power2] 12
20:04:14.860 -> hasend/power2: 12
20:04:23.246 -> MQTT >> [hasend/power1] 845
20:04:23.246 -> 845
20:04:23.511 -> MQTT >> [hasend/tempodr] 24.3
20:04:23.511 -> hasend/tempodr: 24.3
20:04:24.867 -> MQTT >> [hasend/power2] 12
20:04:24.902 -> hasend/power2: 12
20:04:33.233 -> MQTT >> [hasend/power1] 846
20:04:33.233 -> 846
20:04:33.406 -> MQTT >> [hasend/tempodr] 24.3
20:04:33.406 -> hasend/tempodr: 24.3
20:04:34.885 -> MQTT >> [hasend/power2] 12
20:04:34.885 -> hasend/power2: 12
20:04:43.360 -> MQTT >> [hasend/power1] 883
20:04:43.360 -> 883
20:04:43.535 -> MQTT >> [hasend/tempodr] 24.3
20:04:43.535 -> hasend/tempodr: 24.3
20:04:44.918 -> MQTT >> [hasend/power2] 12
20:04:44.952 -> hasend/power2: 12
20:04:53.254 -> MQTT >> [hasend/power1] 885
20:04:53.254 -> 885
20:04:53.324 -> MQTT >> [hasend/tempodr] 24.3
20:04:53.324 -> hasend/tempodr: 24.3
20:04:53.360 -> MQTT >> [hasend/energydly] 20.51999999999998
20:04:53.360 -> hasend/energydly: 20.51999999999998
20:04:53.435 -> MQTT >> [hasend/energymnthly] 60.259999999999980
20:04:53.435 -> hasend/energymnthly: 60.259999999999980
20:04:54.878 -> MQTT >> [hasend/power2] 12
20:04:54.878 -> hasend/power2: 12
20:05:03.187 -> MQTT >> [hasend/power1] 893
20:05:03.187 -> 893
20:05:03.253 -> MQTT >> [hasend/tempodr] 24.3
20:05:03.253 -> hasend/tempodr: 24.3
20:05:04.837 -> MQTT >> [hasend/power2] 12
20:05:04.837 -> hasend/power2: 12
20:05:13.261 -> MQTT >> [hasend/power1] 882
20:05:13.261 -> 882
20:05:13.481 -> MQTT >> [hasend/tempodr] 24.3
20:05:13.481 -> hasend/tempodr: 24.3
20:05:14.862 -> MQTT >> [hasend/power2] 12
20:05:14.898 -> hasend/power2: 12
20:05:23.237 -> MQTT >> [hasend/power1] 885
20:05:23.237 -> 885
20:05:23.342 -> MQTT >> [hasend/tempodr] 24.3
20:05:23.342 -> hasend/tempodr: 24.3
20:05:24.880 -> MQTT >> [hasend/power2] 12
20:05:24.880 -> hasend/power2: 12
